<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['w' => 62, 'l' => 170, 'color' => '#0E6B5B', 'pattern' => 'striate']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['w' => 62, 'l' => 170, 'color' => '#0E6B5B', 'pattern' => 'striate']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $top = -50;
    $end = $top + $l;
?>

<g stroke="#2A1238" stroke-linecap="round" stroke-linejoin="round" <?php echo e($attributes); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [1, -1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <g transform="scale(<?php echo e($side); ?> 1)" fill="none">
            <path stroke-width="3" d="M8 -128 C18 -150 30 -152 36 -172 M36 -172 l5 -6" />
            <path stroke-width="3.5" d="M<?php echo e($w * .55); ?> -66 L<?php echo e($w + 30); ?> -92 L<?php echo e($w + 46); ?> -132 l9 -8" />
            <path stroke-width="3.5" d="M<?php echo e($w * .9); ?> -10 L<?php echo e($w + 34); ?> 4 L<?php echo e($w + 56); ?> -22 l11 -5" />
            <path stroke-width="3.5" d="M<?php echo e($w * .8); ?> 50 L<?php echo e($w + 32); ?> 92 L<?php echo e($w + 48); ?> 146 l5 11" />
        </g>
        <g transform="scale(<?php echo e($side); ?> 1)">
            <path fill="<?php echo e($color); ?>" stroke-width="2.5"
                d="M1.5 <?php echo e($top); ?> C<?php echo e($w * .7); ?> <?php echo e($top - 3); ?> <?php echo e($w); ?> <?php echo e($top + 8); ?> <?php echo e($w); ?> <?php echo e($top + 42); ?> C<?php echo e($w); ?> <?php echo e($top + $l * .68); ?> <?php echo e($w * .55); ?> <?php echo e($end - 8); ?> 1.5 <?php echo e($end); ?> Z" />
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pattern === 'striate'): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [.3, .55, .8]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <path fill="none" stroke-width="1.2" opacity=".7" d="M<?php echo e($w * $f); ?> <?php echo e($top + 7); ?> C<?php echo e($w * $f + 3); ?> <?php echo e($top + $l * .5); ?> <?php echo e($w * $f * .85); ?> <?php echo e($top + $l * .75); ?> <?php echo e($w * $f * .5); ?> <?php echo e($end - 16); ?>" />
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php elseif($pattern === 'spots'): ?>
                <circle cx="<?php echo e($w * .5); ?>" cy="<?php echo e($top + $l * .25); ?>" r="<?php echo e($w * .16); ?>" fill="#F6F5E4" stroke-width="1.2" />
                <circle cx="<?php echo e($w * .58); ?>" cy="<?php echo e($top + $l * .55); ?>" r="<?php echo e($w * .13); ?>" fill="#F6F5E4" stroke-width="1.2" />
                <circle cx="<?php echo e($w * .3); ?>" cy="<?php echo e($top + $l * .78); ?>" r="<?php echo e($w * .1); ?>" fill="#F6F5E4" stroke-width="1.2" />
            <?php elseif($pattern === 'band'): ?>
                <path fill="#F6F5E4" stroke-width="1.2" d="M1.5 <?php echo e($top + $l * .32); ?> Q<?php echo e($w * .5); ?> <?php echo e($top + $l * .25); ?> <?php echo e($w); ?> <?php echo e($top + $l * .3); ?> L<?php echo e($w * .94); ?> <?php echo e($top + $l * .5); ?> Q<?php echo e($w * .5); ?> <?php echo e($top + $l * .44); ?> 1.5 <?php echo e($top + $l * .52); ?> Z" />
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <path fill="none" stroke="#F6F5E4" stroke-width="3" opacity=".35" d="M<?php echo e($w * .78); ?> <?php echo e($top + 16); ?> C<?php echo e($w * .86); ?> <?php echo e($top + $l * .3); ?> <?php echo e($w * .8); ?> <?php echo e($top + $l * .5); ?> <?php echo e($w * .68); ?> <?php echo e($top + $l * .66); ?>" />
        </g>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <path fill="<?php echo e($color); ?>" stroke-width="2.5" d="M-22 -96 C-40 -92 -<?php echo e($w * .72); ?> -78 -<?php echo e($w * .76); ?> -54 Q0 -42 <?php echo e($w * .76); ?> -54 C<?php echo e($w * .72); ?> -78 40 -92 22 -96 Q0 -103 -22 -96 Z" />
    <path fill="#2A1238" stroke-width="2" d="M-20 -97 C-24 -122 -12 -134 0 -134 C12 -134 24 -122 20 -97 Q0 -104 -20 -97 Z" />
    <circle cx="-13" cy="-120" r="3" fill="#F6F5E4" stroke="none" />
    <circle cx="13" cy="-120" r="3" fill="#F6F5E4" stroke="none" />
</g>
<?php /**PATH C:\Users\ROG\Documents\portfolio\resources\views/components/beetle.blade.php ENDPATH**/ ?>