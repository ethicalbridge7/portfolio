<div class="mock">
    <p class="mock-url" x-text="hunt.url"></p>
    <template x-for="row in hunt.rows" x-bind:key="row.id">
        <button type="button" x-bind:data-row="row.id" x-bind:class="[row.cls, isFound(row.id) && 'is-fixed']" x-on:click="guess(row.id)">
            <span x-text="isFound(row.id) ? (row.fixed?.label ?? row.label) : row.label"></span>
            <span x-show="row.value" x-text="isFound(row.id) ? (row.fixed?.value ?? row.value) : row.value"></span>
        </button>
    </template>
</div>

<div class="hunt-progress">
    <?php if (isset($component)) { $__componentOriginal4cc377eda9b63b796b6668ee7832d023 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cc377eda9b63b796b6668ee7832d023 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::badge.index','data' => ['color' => 'emerald','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'emerald','size' => 'sm']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<span x-text="found.length"></span>&nbsp;of 4 found <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $attributes = $__attributesOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $component = $__componentOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__componentOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
    <p class="identify-hint" role="status" x-show="hint" x-text="hint"></p>
</div>

<ul class="hunt-reports">
    <template x-for="id in found" x-bind:key="id">
        <li>
            <strong x-text="hunt.bugs[id]?.title"></strong>
            <span x-text="hunt.bugs[id]?.report"></span>
        </li>
    </template>
</ul>
<?php /**PATH C:\Users\ROG\Documents\portfolio\resources\views/components/bug-hunt.blade.php ENDPATH**/ ?>