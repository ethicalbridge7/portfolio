<?php
    $site = rtrim(config('app.url'), '/');
    $seoTitle = 'Prosper Amutah | Software Engineer & QA Engineer';
    $seoDescription = 'Software engineer and QA engineer building and testing web and mobile apps with Laravel, React, Next.js and Flutter. Available for remote work worldwide.';
    $seoSkills = ['Software Engineering', 'Full-Stack Web Development', 'Laravel', 'PHP', 'React', 'Next.js', 'TypeScript', 'Node.js', 'Python', 'Flutter', 'Mobile App Development', 'REST API Development', 'PostgreSQL', 'MySQL', 'Docker', 'Software Quality Assurance', 'API Testing', 'Regression Testing', 'User Acceptance Testing'];
    $person = [
        '@type' => 'Person',
        '@id' => $site.'/#prosper',
        'name' => 'Prosper Amutah',
        'url' => $site.'/',
        'image' => $site.(file_exists(public_path('img/prosper.jpg')) ? '/img/prosper.jpg' : '/img/og.jpg'),
        'jobTitle' => ['Software Engineer', 'Quality Assurance Engineer'],
        'description' => $seoDescription,
        'email' => 'mailto:contact@prosperamutah.online',
        'telephone' => '+2349077989776',
        'address' => ['@type' => 'PostalAddress', 'addressCountry' => 'NG'],
        'alumniOf' => ['@type' => 'CollegeOrUniversity', 'name' => 'Michael Okpara University of Agriculture, Umudike'],
        'knowsAbout' => $seoSkills,
        'sameAs' => ['https://linkedin.com/in/prosper-amutah-667530241', 'https://github.com/ethicalbridge7'],
    ];
    $schema = [
        '@context' => 'https://schema.org',
        '@graph' => [
            $person,
            ['@type' => 'WebSite', '@id' => $site.'/#website', 'url' => $site.'/', 'name' => 'Prosper Amutah', 'inLanguage' => 'en'],
            ['@type' => 'ProfilePage', 'url' => $site.'/', 'name' => $seoTitle, 'mainEntity' => ['@id' => $site.'/#prosper'], 'isPartOf' => ['@id' => $site.'/#website']],
        ],
    ];
    $services = [
        ['Full-stack web development', 'Web applications and SaaS products built with Laravel, PHP, React, Next.js, TypeScript and Node.js.'],
        ['Mobile app development', 'Cross-platform Android and iOS apps built with Flutter and Dart.'],
        ['API development', 'Secure REST APIs with authentication, rate limiting and payment integration.'],
        ['Databases and deployment', 'Relational schemas in PostgreSQL and MySQL, row-level security, and Docker.'],
        ['Software QA testing', 'Manual test plans covering functional, regression, integration and user acceptance testing.'],
        ['API testing', 'Test cases that verify responses, behavior and failure paths, with defect reports developers can act on.'],
    ];
    $skills = [
        'left' => [
            ['Web', 'React, Next.js, Tailwind CSS'],
            ['Mobile', 'Flutter, Dart'],
            ['Backend', 'Laravel, Node.js, REST APIs'],
        ],
        'right' => [
            ['Languages', 'TypeScript, Python, PHP'],
            ['Data and delivery', 'PostgreSQL, MySQL, Docker'],
            ['Testing', 'API, functional, regression, integration, UAT'],
        ],
    ];
    // Drop a picture at the given public path and it replaces the placeholder.
    $projects = [
        [
            'name' => 'JobProfi', 'image' => 'img/projects/jobprofi.jpg', 'url' => 'https://usejobprofi.com',
            'stack' => ['Laravel', 'MySQL', 'Tailwind CSS', 'Flutter'],
            'text' => 'A job-search platform with application tracking, a career coach, a job analyzer and a résumé builder that exports PDFs. Used by more than 70 people, with Flutterwave and Paystack payments.',
        ],
        [
            'name' => 'Voice Of The Youths', 'image' => 'img/projects/voty.jpg', 'url' => 'https://voty.ng',
            'stack' => ['TypeScript', 'Next.js', 'PostgreSQL', 'Supabase'],
            'text' => 'An educational video platform for young members, with subscriptions, trivia and voting. 34 REST endpoints, phone login over SMS, rate limiting and row-level security.',
        ],
        [
            'name' => 'DYL Logistics', 'image' => 'img/projects/dyl.jpg', 'url' => 'https://dyllogistics.com',
            'stack' => ['PHP', 'Laravel', 'Livewire', 'Flux UI', 'MySQL', 'Tailwind CSS', 'JavaScript'],
            'text' => 'A delivery service across Enugu for food, groceries, pharmacy items, parcels and errands, with verified riders, partner stores and a dashboard that tracks every order.',
        ],
        [
            'name' => 'University Academic Management System', 'image' => 'img/projects/uams.jpg', 'url' => null,
            'stack' => ['React', 'Laravel', 'PostgreSQL', 'Docker', 'TypeScript'],
            'text' => 'Enrollment, results and student self-service, shaped by interviews and surveys with more than 100 students and staff. A working prototype, demonstrated to university management.',
        ],
    ];
    $bugs = [
        ['Typo', '#27408B', 'plain', 56, 150, 'People read what they expect to read, so I write defect reports with exact steps to reproduce.'],
        ['Wrong date', '#C98A12', 'spots', 66, 140, 'An empty date shows as 1 January 1970. VOTY login codes expire in 10 minutes, so time has to be right.'],
        ['Off-by-one error', '#0E6B5B', 'band', 60, 165, 'A change upstream quietly breaks something far away. Regression test plans exist to catch it.'],
        ['Broken layout', '#B80F4A', 'striate', 54, 180, 'Screens have to hold on every browser and phone, especially at checkout.'],
        ['Exposed admin control', '#2A1238', 'spots', 70, 150, 'Hiding a button is not access control. I enforce roles on the server, in Laravel.'],
        ['Bad number', '#27408B', 'striate', 64, 160, 'A figure on a screen is only as good as the path it took to get there. I check the path.'],
        ['Runaway progress', '#0E6B5B', 'spots', 58, 172, 'Idempotent saves on VOTY mean a repeated request can’t push a video past 100%.'],
    ];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($seoTitle); ?></title>
    <meta name="description" content="<?php echo e($seoDescription); ?>">
    <meta name="keywords" content="Prosper Amutah, software engineer, software developer, full-stack developer, QA engineer, software tester, Laravel developer, React developer, Next.js developer, Flutter developer, API testing, hire remote software engineer">
    <meta name="author" content="Prosper Amutah">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
    <meta name="theme-color" content="#2A1238">
    <link rel="canonical" href="<?php echo e($site); ?>/">
    <meta property="og:type" content="profile">
    <meta property="og:site_name" content="Prosper Amutah">
    <meta property="og:title" content="<?php echo e($seoTitle); ?>">
    <meta property="og:description" content="<?php echo e($seoDescription); ?>">
    <meta property="og:url" content="<?php echo e($site); ?>/">
    <meta property="og:image" content="<?php echo e($site); ?>/img/og.jpg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="Prosper Amutah, Software Engineer and QA Engineer">
    <meta property="profile:first_name" content="Prosper">
    <meta property="profile:last_name" content="Amutah">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($seoTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($seoDescription); ?>">
    <meta name="twitter:image" content="<?php echo e($site); ?>/img/og.jpg">
    <script type="application/ld+json"><?php echo json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG); ?></script>
    <link rel="icon" href="/favicon.ico" sizes="48x48">
    <link rel="icon" href="/favicon.svg" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=alegreya:400,400i,500,700|besley:500,800,900" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body x-data="page">

<?php if (isset($component)) { $__componentOriginal6cdb42459f68d5ce2e97131ae988e57c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cdb42459f68d5ce2e97131ae988e57c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::brand','data' => ['class' => 'site-logo','href' => '/','logo' => '/favicon.svg','alt' => 'Prosper Amutah, home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::brand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'site-logo','href' => '/','logo' => '/favicon.svg','alt' => 'Prosper Amutah, home']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cdb42459f68d5ce2e97131ae988e57c)): ?>
<?php $attributes = $__attributesOriginal6cdb42459f68d5ce2e97131ae988e57c; ?>
<?php unset($__attributesOriginal6cdb42459f68d5ce2e97131ae988e57c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cdb42459f68d5ce2e97131ae988e57c)): ?>
<?php $component = $__componentOriginal6cdb42459f68d5ce2e97131ae988e57c; ?>
<?php unset($__componentOriginal6cdb42459f68d5ce2e97131ae988e57c); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginald33a3439ec8f8da64b388b23a8637b39 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald33a3439ec8f8da64b388b23a8637b39 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.index','data' => ['class' => 'site-nav','ariaLabel' => 'Sections']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'site-nav','aria-label' => 'Sections']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php if (isset($component)) { $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.item','data' => ['class' => 'nav-story','href' => '#story']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-story','href' => '#story']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Story <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $attributes = $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $component = $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.item','data' => ['class' => 'nav-projects','href' => '#projects']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-projects','href' => '#projects']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Projects <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $attributes = $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $component = $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.item','data' => ['class' => 'nav-contact','href' => '#contact']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'nav-contact','href' => '#contact']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Contact <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $attributes = $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $component = $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.item','data' => ['xOn:click' => 'openResume()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'openResume()']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Resume <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $attributes = $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $component = $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.item','data' => ['xOn:click' => 'openIdentify()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'openIdentify()']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Identify bugs <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $attributes = $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $component = $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::navbar.item','data' => ['xOn:click' => 'openSim()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::navbar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'openSim()']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Simulation <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $attributes = $__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__attributesOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48)): ?>
<?php $component = $__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48; ?>
<?php unset($__componentOriginalc4cbba45ed073bedf6d5fbbd59b58e48); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald33a3439ec8f8da64b388b23a8637b39)): ?>
<?php $attributes = $__attributesOriginald33a3439ec8f8da64b388b23a8637b39; ?>
<?php unset($__attributesOriginald33a3439ec8f8da64b388b23a8637b39); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald33a3439ec8f8da64b388b23a8637b39)): ?>
<?php $component = $__componentOriginald33a3439ec8f8da64b388b23a8637b39; ?>
<?php unset($__componentOriginald33a3439ec8f8da64b388b23a8637b39); ?>
<?php endif; ?>

<header class="hero">
    <div class="intro">
        <h1 class="name">Prosper Amutah <span>Software Engineer &amp; QA Engineer</span></h1>
        <p class="tagline">I build software, then try to break it.</p>
        <p class="lede">I’m a full-stack software engineer and QA tester based in Nigeria, working remotely with teams worldwide. I design and ship web and mobile products, then test them the way a stranger would use them.</p>
        <?php if (isset($component)) { $__componentOriginal851cea7dae7408f9c0be85892fea035d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal851cea7dae7408f9c0be85892fea035d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact-links','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal851cea7dae7408f9c0be85892fea035d)): ?>
<?php $attributes = $__attributesOriginal851cea7dae7408f9c0be85892fea035d; ?>
<?php unset($__attributesOriginal851cea7dae7408f9c0be85892fea035d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal851cea7dae7408f9c0be85892fea035d)): ?>
<?php $component = $__componentOriginal851cea7dae7408f9c0be85892fea035d; ?>
<?php unset($__componentOriginal851cea7dae7408f9c0be85892fea035d); ?>
<?php endif; ?>
    </div>

    <figure class="plate">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side => $notes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <dl class="notes-col <?php echo e($side); ?>">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$title, $detail]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="note"><dt><?php echo e($title); ?></dt><dd><?php echo e($detail); ?></dd></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </dl>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <div class="portrait">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('img/prosper.jpg'))): ?>
                <img src="<?php echo e(asset('img/prosper.jpg')); ?>" alt="Portrait of Prosper Amutah">
            <?php else: ?>
                <span class="monogram" aria-hidden="true">PA</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <svg class="pinned" viewBox="-130 -190 260 370" aria-hidden="true"><?php if (isset($component)) { $__componentOriginal32c3289e71c744a09f682fbfff97541b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32c3289e71c744a09f682fbfff97541b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.beetle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('beetle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32c3289e71c744a09f682fbfff97541b)): ?>
<?php $attributes = $__attributesOriginal32c3289e71c744a09f682fbfff97541b; ?>
<?php unset($__attributesOriginal32c3289e71c744a09f682fbfff97541b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32c3289e71c744a09f682fbfff97541b)): ?>
<?php $component = $__componentOriginal32c3289e71c744a09f682fbfff97541b; ?>
<?php unset($__componentOriginal32c3289e71c744a09f682fbfff97541b); ?>
<?php endif; ?></svg>
        </div>
        <figcaption>Fig. 1. The software engineer, with tools.</figcaption>
    </figure>
</header>

<main id="story" class="story" x-ref="story">
    <svg class="trail" aria-hidden="true"><path x-ref="trail" /></svg>
    <svg class="walker" x-ref="walker" viewBox="-130 -190 260 370" aria-hidden="true"><?php if (isset($component)) { $__componentOriginal32c3289e71c744a09f682fbfff97541b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32c3289e71c744a09f682fbfff97541b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.beetle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('beetle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32c3289e71c744a09f682fbfff97541b)): ?>
<?php $attributes = $__attributesOriginal32c3289e71c744a09f682fbfff97541b; ?>
<?php unset($__attributesOriginal32c3289e71c744a09f682fbfff97541b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32c3289e71c744a09f682fbfff97541b)): ?>
<?php $component = $__componentOriginal32c3289e71c744a09f682fbfff97541b; ?>
<?php unset($__componentOriginal32c3289e71c744a09f682fbfff97541b); ?>
<?php endif; ?></svg>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['where' => 'Michael Okpara University of Agriculture','place' => 'Umudike, Abia State','when' => 'December 2019 to October 2024']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['where' => 'Michael Okpara University of Agriculture','place' => 'Umudike, Abia State','when' => 'December 2019 to October 2024']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 1</p>
        <h2>It started with learning how the machine thinks.</h2>
        <p>I studied Computer Science at Michael Okpara University of Agriculture and finished in October 2024 with a 3.92 GPA.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['class' => 'drift','where' => 'Berge Technology Hub','place' => 'Umuahia, Abia State','when' => 'June 2023 to October 2024']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'drift','where' => 'Berge Technology Hub','place' => 'Umuahia, Abia State','when' => 'June 2023 to October 2024']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 2</p>
        <h2>Then real people had to get through checkout.</h2>
        <p>While still studying, I joined Berge Technology Hub and built features for an e-commerce platform in Laravel and MySQL. Checkout speed and user engagement improved by 30%.</p>
        <p>I delivered the interface across browsers and phones in Bootstrap, Tailwind CSS and TypeScript.</p>
        <p>I also learned the habit of Git-based code review: someone else reads your work before your users do.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['where' => 'University Academic Management System','place' => 'React, Laravel, PostgreSQL, Docker, TypeScript','when' => 'Over 100 students and staff consulted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['where' => 'University Academic Management System','place' => 'React, Laravel, PostgreSQL, Docker, TypeScript','when' => 'Over 100 students and staff consulted']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 3</p>
        <h2>Before writing the code, I asked a hundred people.</h2>
        <p>Students and staff told me, through interviews and surveys, how academic records really moved through a university. From that I designed and built a working prototype: enrollment, self-service for students, dashboards for administrators, and uploading and editing of results.</p>
        <p>Students sign in with their matriculation numbers, and I demonstrated the system to university management, using institutional data, during their workflow evaluation.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['class' => 'drift','where' => 'JobProfi','place' => 'Laravel, MySQL, Tailwind CSS, Flutter','when' => 'Used by more than 70 people']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'drift','where' => 'JobProfi','place' => 'Laravel, MySQL, Tailwind CSS, Flutter','when' => 'Used by more than 70 people']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 4</p>
        <h2>Next I built a place to run a job search.</h2>
        <p>JobProfi tracks applications and manages résumés. It has a career coach, interview preparation, and a job analyzer that compares your qualifications with what a role asks for. Its résumé builder previews live and exports a PDF in one click.</p>
        <p>Automated follow-up emails increased engagement by 35%. Payments run through Flutterwave and Paystack, and there is a Flutter mobile app.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['where' => 'Nu3careplus LTD, remote, since December 2024','place' => 'iHealth Wellness Foundation, New York','when' => 'February 2025 to January 2026']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['where' => 'Nu3careplus LTD, remote, since December 2024','place' => 'iHealth Wellness Foundation, New York','when' => 'February 2025 to January 2026']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 5</p>
        <h2>So I crossed to the other side of the bug report.</h2>
        <p>At Nu3careplus I design test cases for applications and APIs, checking responses and behavior, and reporting what fails. At iHealth Wellness Foundation I wrote and ran manual test plans for web and mobile apps: functional, regression, integration and UAT.</p>
        <p>The teams sat across time zones, so a bug report had to make sense to someone who was asleep when I filed it. Release schedules depended on that.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['class' => 'drift','where' => 'Voice Of The Youths','place' => 'TypeScript, Next.js, PostgreSQL, Supabase','when' => '34 endpoints, 18 migrations']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'drift','where' => 'Voice Of The Youths','place' => 'TypeScript, Next.js, PostgreSQL, Supabase','when' => '34 endpoints, 18 migrations']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 6</p>
        <h2>After that, I built as if I would be the one attacking it.</h2>
        <p>VOTY is an educational platform where young members subscribe to videos, answer trivia on what they watched, and vote. I shipped its 34 REST endpoints.</p>
        <p>Login is by phone, through a Nigerian carrier SMS gateway. Codes die after 10 minutes. A sliding-window limiter allows 5 code requests a minute and 10 verification attempts in 5 minutes. Row-level security keeps each member’s progress, votes and profile to themselves.</p>
        <p>Playback resumes where you left off and completes at 90% watched.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalb957aead90bd9b6854e9d334c84b236e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb957aead90bd9b6854e9d334c84b236e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chapter','data' => ['where' => 'Havilla University','place' => 'Nde-Ikom, Cross River State','when' => 'December 2025 to October 2026']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chapter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['where' => 'Havilla University','place' => 'Nde-Ikom, Cross River State','when' => 'December 2025 to October 2026']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

        <p class="chapter-no">Chapter 7</p>
        <h2>And then I stood in front of a class and taught it.</h2>
        <p>As lecturer and Software Engineering Department Coordinator, I taught undergraduate Computer Science, Software Engineering and Cyber Security. I wrote the lectures, practicals and examinations, and supported curriculum development and academic planning.</p>
        <p>The lesson I most wanted to pass on: assume it’s broken, then find out how.</p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $attributes = $__attributesOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__attributesOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb957aead90bd9b6854e9d334c84b236e)): ?>
<?php $component = $__componentOriginalb957aead90bd9b6854e9d334c84b236e; ?>
<?php unset($__componentOriginalb957aead90bd9b6854e9d334c84b236e); ?>
<?php endif; ?>
</main>

<section id="projects" class="projects" aria-labelledby="projects-title">
    <h2 id="projects-title">Things I’ve built</h2>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <article class="project">
            <div class="shot">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path($project['image']))): ?>
                    <img src="<?php echo e(asset($project['image'])); ?>" alt="Screenshot of <?php echo e($project['name']); ?>" loading="lazy">
                <?php else: ?>
                    <span aria-hidden="true"><?php echo e($project['name']); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div class="project-text">
                <h3><?php echo e($project['name']); ?></h3>
                <p><?php echo e($project['text']); ?></p>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project['stack']): ?>
                    <div class="stack">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $project['stack']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal4cc377eda9b63b796b6668ee7832d023 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cc377eda9b63b796b6668ee7832d023 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::badge.index','data' => ['size' => 'sm','class' => 'tool']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm','class' => 'tool']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<?php echo e($tool); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $attributes = $__attributesOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $component = $__componentOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__componentOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project['url']): ?>
                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['icon:trailing' => 'arrow-top-right-on-square','href' => ''.e($project['url']).'','target' => '_blank','rel' => 'noopener']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon:trailing' => 'arrow-top-right-on-square','href' => ''.e($project['url']).'','target' => '_blank','rel' => 'noopener']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Visit site <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </article>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</section>

<section id="services" class="services" aria-labelledby="services-title">
    <h2 id="services-title">What you can hire me for</h2>
    <p class="services-intro">I work remotely with startups, companies and universities in any time zone.</p>
    <dl>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$service, $detail]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div><dt><?php echo e($service); ?></dt><dd><?php echo e($detail); ?></dd></div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </dl>
</section>

<section id="bugs" class="drawer" aria-labelledby="drawer-title">
    <h2 id="drawer-title">Bugs I’ve learned to look for</h2>
    <ul class="specimens">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $bugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$plain, $color, $pattern, $w, $l, $note]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <li>
                <svg viewBox="-130 -190 260 370" aria-hidden="true"><?php if (isset($component)) { $__componentOriginal32c3289e71c744a09f682fbfff97541b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32c3289e71c744a09f682fbfff97541b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.beetle','data' => ['w' => $w,'l' => $l,'color' => $color,'pattern' => $pattern]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('beetle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['w' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($w),'l' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($l),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($color),'pattern' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pattern)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32c3289e71c744a09f682fbfff97541b)): ?>
<?php $attributes = $__attributesOriginal32c3289e71c744a09f682fbfff97541b; ?>
<?php unset($__attributesOriginal32c3289e71c744a09f682fbfff97541b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32c3289e71c744a09f682fbfff97541b)): ?>
<?php $component = $__componentOriginal32c3289e71c744a09f682fbfff97541b; ?>
<?php unset($__componentOriginal32c3289e71c744a09f682fbfff97541b); ?>
<?php endif; ?></svg>
                <div>
                    <h3><?php echo e($plain); ?></h3>
                    <p><?php echo e($note); ?></p>
                </div>
            </li>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <li class="eighth"><a href="mailto:contact@prosperamutah.online?subject=Found%20a%20bug">Found another one on this site? Tell me.</a></li>
    </ul>

    <div id="contact" class="hire">
        <p>If you need someone who will build it and then try to break it, write to me.</p>
        <?php if (isset($component)) { $__componentOriginal851cea7dae7408f9c0be85892fea035d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal851cea7dae7408f9c0be85892fea035d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact-links','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal851cea7dae7408f9c0be85892fea035d)): ?>
<?php $attributes = $__attributesOriginal851cea7dae7408f9c0be85892fea035d; ?>
<?php unset($__attributesOriginal851cea7dae7408f9c0be85892fea035d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal851cea7dae7408f9c0be85892fea035d)): ?>
<?php $component = $__componentOriginal851cea7dae7408f9c0be85892fea035d; ?>
<?php unset($__componentOriginal851cea7dae7408f9c0be85892fea035d); ?>
<?php endif; ?>
    </div>

    <dl class="cv-notes">
        <div><dt>Education</dt><dd>BSc Computer Science, Michael Okpara University of Agriculture, 2024. GPA 3.92.</dd></div>
        <div><dt>Teaching</dt><dd>Computer Science, Software Engineering and Cyber Security at Havilla University.</dd></div>
        <div><dt>Certificates</dt><dd>Software Engineering Job Simulation, Wells Fargo on Forage, September 2025. Software Development Job Simulation, Datacom on Forage, September 2025.</dd></div>
        <div><dt>Research interests</dt><dd>Machine learning, AI and security.</dd></div>
    </dl>
</section>

<?php if (isset($component)) { $__componentOriginal8cc9d3143946b992b324617832699c5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8cc9d3143946b992b324617832699c5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.index','data' => ['name' => 'identify','class' => 'identify-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'identify','class' => 'identify-modal']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['size' => 'xl','level' => '2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'xl','level' => '2']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Identify the bugs <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0638ebfbd490c7a414275d493e14cb4e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0638ebfbd490c7a414275d493e14cb4e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::text','data' => ['class' => 'identify-intro']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'identify-intro']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
This checkout has four bugs. Click each part you think is broken. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0638ebfbd490c7a414275d493e14cb4e)): ?>
<?php $attributes = $__attributesOriginal0638ebfbd490c7a414275d493e14cb4e; ?>
<?php unset($__attributesOriginal0638ebfbd490c7a414275d493e14cb4e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0638ebfbd490c7a414275d493e14cb4e)): ?>
<?php $component = $__componentOriginal0638ebfbd490c7a414275d493e14cb4e; ?>
<?php unset($__componentOriginal0638ebfbd490c7a414275d493e14cb4e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bug-hunt','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bug-hunt'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4)): ?>
<?php $attributes = $__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4; ?>
<?php unset($__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4)): ?>
<?php $component = $__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4; ?>
<?php unset($__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4); ?>
<?php endif; ?>
    <p class="hunt-done" x-show="huntDone">All four fixed. These were planted, but it’s how I report the real ones.</p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $attributes = $__attributesOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__attributesOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $component = $__componentOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__componentOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal8cc9d3143946b992b324617832699c5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8cc9d3143946b992b324617832699c5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.index','data' => ['name' => 'simulate','class' => 'sim-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'simulate','class' => 'sim-modal']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['size' => 'xl','level' => '2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'xl','level' => '2']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Hire me: a simulation <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0638ebfbd490c7a414275d493e14cb4e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0638ebfbd490c7a414275d493e14cb4e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::text','data' => ['class' => 'identify-intro']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'identify-intro']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
You play the client. Sample project, sample timeline, computer-generated client photo. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0638ebfbd490c7a414275d493e14cb4e)): ?>
<?php $attributes = $__attributesOriginal0638ebfbd490c7a414275d493e14cb4e; ?>
<?php unset($__attributesOriginal0638ebfbd490c7a414275d493e14cb4e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0638ebfbd490c7a414275d493e14cb4e)): ?>
<?php $component = $__componentOriginal0638ebfbd490c7a414275d493e14cb4e; ?>
<?php unset($__componentOriginal0638ebfbd490c7a414275d493e14cb4e); ?>
<?php endif; ?>

    <ol class="sim-steps">
        <template x-for="(name, i) in stages" x-bind:key="name">
            <li x-bind:class="{ now: i === stage, done: i < stage }" x-text="name"></li>
        </template>
    </ol>

    <div class="sim-talk" x-show="stage < 2">
        <div class="sim-people">
            <?php if (isset($component)) { $__componentOriginalf61e0c875d2d54bd513b300e3d0be348 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf61e0c875d2d54bd513b300e3d0be348 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sim-person','data' => ['image' => 'img/sim/client.jpg','initial' => 'A','name' => 'Ani','role' => 'Sample client']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sim-person'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'img/sim/client.jpg','initial' => 'A','name' => 'Ani','role' => 'Sample client']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf61e0c875d2d54bd513b300e3d0be348)): ?>
<?php $attributes = $__attributesOriginalf61e0c875d2d54bd513b300e3d0be348; ?>
<?php unset($__attributesOriginalf61e0c875d2d54bd513b300e3d0be348); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf61e0c875d2d54bd513b300e3d0be348)): ?>
<?php $component = $__componentOriginalf61e0c875d2d54bd513b300e3d0be348; ?>
<?php unset($__componentOriginalf61e0c875d2d54bd513b300e3d0be348); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf61e0c875d2d54bd513b300e3d0be348 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf61e0c875d2d54bd513b300e3d0be348 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sim-person','data' => ['image' => 'img/prosper.jpg','initial' => 'P','name' => 'Prosper','role' => 'Engineer']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sim-person'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'img/prosper.jpg','initial' => 'P','name' => 'Prosper','role' => 'Engineer']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf61e0c875d2d54bd513b300e3d0be348)): ?>
<?php $attributes = $__attributesOriginalf61e0c875d2d54bd513b300e3d0be348; ?>
<?php unset($__attributesOriginalf61e0c875d2d54bd513b300e3d0be348); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf61e0c875d2d54bd513b300e3d0be348)): ?>
<?php $component = $__componentOriginalf61e0c875d2d54bd513b300e3d0be348; ?>
<?php unset($__componentOriginalf61e0c875d2d54bd513b300e3d0be348); ?>
<?php endif; ?>
        </div>
        <div class="sim-thread">
            <div class="sim-chat">
                <template x-for="(message, i) in messages" x-bind:key="i">
                    <p x-bind:class="message.who" x-text="message.text"></p>
                </template>
            </div>
            <div class="sim-choices">
                <template x-for="option in options" x-bind:key="option.label">
                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['class' => 'sim-choice','xOn:click' => 'choose(option)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'sim-choice','x-on:click' => 'choose(option)']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
<span x-text="option.label"></span> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                </template>
            </div>
        </div>
    </div>

    <div class="sim-build" x-show="stage === 2">
        <ul class="sim-tasks">
            <template x-for="(task, i) in project?.tasks ?? []" x-bind:key="task.name">
                <li x-bind:class="{ done: i < taskIndex, now: i === taskIndex }" x-text="task.name"></li>
            </template>
        </ul>
        <pre class="sim-editor"><code x-text="code"></code></pre>
    </div>

    <div class="sim-test" x-show="stage === 3">
        <p class="sim-note" x-text="hunt.staging"></p>
        <?php if (isset($component)) { $__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bug-hunt','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bug-hunt'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4)): ?>
<?php $attributes = $__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4; ?>
<?php unset($__attributesOriginalc7e1a837c0f67a2dfe58519aecd55ee4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4)): ?>
<?php $component = $__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4; ?>
<?php unset($__componentOriginalc7e1a837c0f67a2dfe58519aecd55ee4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'primary','xShow' => 'huntDone','xOn:click' => 'ship()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'primary','x-show' => 'huntDone','x-on:click' => 'ship()']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Ship it <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
    </div>

    <div class="sim-ship" x-show="stage === 4">
        <pre class="sim-editor"><code x-text="deploy"></code></pre>
        <div x-show="shipped">
            <dl class="sim-stats">
                <div><dt>Delivered on</dt><dd>Day <span x-text="day"></span></dd></div>
                <div><dt>Tasks finished</dt><dd x-text="project?.tasks.length"></dd></div>
                <div><dt>Bugs that reached users</dt><dd>0</dd></div>
            </dl>
            <p class="sim-note">That was the sample version. The real one starts with an email.</p>
            <div class="actions">
                <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['icon' => 'envelope','href' => 'mailto:contact@prosperamutah.online?subject=Let%27s%20build%20something']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'envelope','href' => 'mailto:contact@prosperamutah.online?subject=Let%27s%20build%20something']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Do this for real <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['xOn:click' => 'openSim()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'openSim()']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Play again <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $attributes = $__attributesOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__attributesOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $component = $__componentOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__componentOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal8cc9d3143946b992b324617832699c5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8cc9d3143946b992b324617832699c5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.index','data' => ['name' => 'resume','class' => 'resume-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'resume','class' => 'resume-modal']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="resume-head">
        <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['size' => 'lg','level' => '2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'lg','level' => '2']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Resume <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['size' => 'sm','icon' => 'arrow-down-tray','href' => '/cv.pdf','download' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm','icon' => 'arrow-down-tray','href' => '/cv.pdf','download' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
Download PDF <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
    </div>
    <p class="resume-status" x-show="resumeStatus" x-text="resumeStatus" role="status"></p>
    <div class="resume-pages" tabindex="0" aria-label="Resume pages"></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $attributes = $__attributesOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__attributesOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $component = $__componentOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__componentOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body>
</html>
<?php /**PATH C:\Users\ROG\Documents\portfolio\resources\views/welcome.blade.php ENDPATH**/ ?>