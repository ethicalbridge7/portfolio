<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['place', 'when', 'where']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['place', 'when', 'where']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<article <?php echo e($attributes->merge(['class' => 'chapter'])); ?>>
    <div class="chapter-body"><?php echo e($slot); ?></div>
    <aside class="field-label">
        <span><?php echo e($where); ?></span>
        <span><?php echo e($place); ?></span>
        <span><?php echo e($when); ?></span>
    </aside>
</article>
<?php /**PATH C:\Users\ROG\Documents\portfolio\resources\views/components/chapter.blade.php ENDPATH**/ ?>