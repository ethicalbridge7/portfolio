<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/robots.txt', fn () => response(
    "User-agent: *\nAllow: /\n\nSitemap: ".rtrim(config('app.url'), '/')."/sitemap.xml\n"
)->header('Content-Type', 'text/plain'));

Route::get('/sitemap.xml', fn () => response(
    '<?xml version="1.0" encoding="UTF-8"?>'."\n"
    .'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>'
    .e(rtrim(config('app.url'), '/').'/').'</loc><priority>1.0</priority></url></urlset>'."\n"
)->header('Content-Type', 'application/xml'));
